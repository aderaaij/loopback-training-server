--
-- PostgreSQL database dump
--

\restrict HJYeNNWX5itBwdvOJGKIip9J4YnOazu2YfjrN0k9pbYZZpWwDRA5QTBetaAr2SA

-- Dumped from database version 16.15 (Debian 16.15-1.pgdg13+2)
-- Dumped by pg_dump version 17.11 (Debian 17.11-0+deb13u1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: training-api
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO "training-api";

--
-- Name: api_tokens; Type: TABLE; Schema: public; Owner: training-api
--

CREATE TABLE public.api_tokens (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    token_hash character varying(64) NOT NULL,
    name text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    last_used_at timestamp with time zone,
    expires_at timestamp with time zone,
    last_user_agent text
);


ALTER TABLE public.api_tokens OWNER TO "training-api";

--
-- Name: auth_events; Type: TABLE; Schema: public; Owner: training-api
--

CREATE TABLE public.auth_events (
    id uuid NOT NULL,
    event character varying(40) NOT NULL,
    username text,
    user_id uuid,
    actor_user_id uuid,
    ip character varying(64),
    detail jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.auth_events OWNER TO "training-api";

--
-- Name: daily_health_metrics; Type: TABLE; Schema: public; Owner: training-api
--

CREATE TABLE public.daily_health_metrics (
    id uuid NOT NULL,
    date date NOT NULL,
    sleep_duration double precision,
    sleep_stages jsonb,
    resting_heart_rate double precision,
    hrv_sdnn double precision,
    weight double precision,
    vo2_max double precision,
    steps integer,
    active_energy_burned double precision,
    body_fat_percentage double precision,
    lean_body_mass double precision,
    respiratory_rate double precision,
    spo2 double precision,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL,
    user_id uuid NOT NULL,
    basal_energy_burned double precision
);


ALTER TABLE public.daily_health_metrics OWNER TO "training-api";

--
-- Name: daily_nutrition; Type: TABLE; Schema: public; Owner: training-api
--

CREATE TABLE public.daily_nutrition (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    date date NOT NULL,
    energy_kcal double precision,
    carbs_g double precision,
    protein_g double precision,
    fat_g double precision,
    saturated_fat_g double precision,
    fiber_g double precision,
    sugar_g double precision,
    sodium_mg double precision,
    potassium_mg double precision,
    cholesterol_mg double precision,
    water_ml double precision,
    caffeine_mg double precision,
    micros jsonb,
    entry_count integer,
    sources jsonb,
    partial boolean DEFAULT false NOT NULL,
    created_at timestamp without time zone DEFAULT now() NOT NULL,
    updated_at timestamp without time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.daily_nutrition OWNER TO "training-api";

--
-- Name: plan_note; Type: TABLE; Schema: public; Owner: training-api
--

CREATE TABLE public.plan_note (
    id uuid NOT NULL,
    plan_id uuid,
    kind character varying(32) NOT NULL,
    summary character varying(280) NOT NULL,
    body text,
    importance integer DEFAULT 2 NOT NULL,
    conversation_id character varying(64),
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    user_id uuid NOT NULL,
    CONSTRAINT plan_note_importance_range CHECK (((importance >= 1) AND (importance <= 3)))
);


ALTER TABLE public.plan_note OWNER TO "training-api";

--
-- Name: plans; Type: TABLE; Schema: public; Owner: training-api
--

CREATE TABLE public.plans (
    id uuid NOT NULL,
    name text NOT NULL,
    activity_type character varying(100) NOT NULL,
    status character varying(50) NOT NULL,
    start_date date NOT NULL,
    end_date date,
    description text,
    metadata jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    user_id uuid NOT NULL
);


ALTER TABLE public.plans OWNER TO "training-api";

--
-- Name: sleep_samples; Type: TABLE; Schema: public; Owner: training-api
--

CREATE TABLE public.sleep_samples (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    start_at timestamp with time zone NOT NULL,
    end_at timestamp with time zone NOT NULL,
    stage character varying(20) NOT NULL,
    source character varying(255) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT sleep_sample_span_positive CHECK ((end_at > start_at)),
    CONSTRAINT sleep_sample_stage_valid CHECK (((stage)::text = ANY ((ARRAY['rem'::character varying, 'core'::character varying, 'deep'::character varying, 'awake'::character varying, 'unspecified'::character varying, 'in_bed'::character varying])::text[])))
);


ALTER TABLE public.sleep_samples OWNER TO "training-api";

--
-- Name: users; Type: TABLE; Schema: public; Owner: training-api
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    username character varying(32) NOT NULL,
    password_hash text,
    display_name text DEFAULT ''::text NOT NULL,
    role character varying(20) DEFAULT 'user'::character varying NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    data_consent text[] DEFAULT ARRAY['training'::text, 'recovery'::text, 'body'::text, 'activity'::text, 'nutrition'::text] NOT NULL,
    data_consent_updated_at timestamp with time zone,
    data_consent_reported_at timestamp with time zone,
    units character varying(16),
    units_updated_at timestamp with time zone
);


ALTER TABLE public.users OWNER TO "training-api";

--
-- Name: workout; Type: TABLE; Schema: public; Owner: training-api
--

CREATE TABLE public.workout (
    id uuid NOT NULL,
    activity_type character varying(100) NOT NULL,
    start_date timestamp with time zone NOT NULL,
    end_date timestamp with time zone NOT NULL,
    duration double precision,
    total_distance double precision,
    total_energy_burned double precision,
    source character varying(255),
    data jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    plan_workout_id uuid,
    effort_score numeric(3,1),
    estimated_effort_score numeric(3,1),
    user_id uuid NOT NULL,
    CONSTRAINT effort_score_range CHECK (((effort_score IS NULL) OR ((effort_score >= (1)::numeric) AND (effort_score <= (10)::numeric)))),
    CONSTRAINT estimated_effort_score_range CHECK (((estimated_effort_score IS NULL) OR ((estimated_effort_score >= (1)::numeric) AND (estimated_effort_score <= (10)::numeric))))
);


ALTER TABLE public.workout OWNER TO "training-api";

--
-- Name: workout_action; Type: TABLE; Schema: public; Owner: training-api
--

CREATE TABLE public.workout_action (
    id uuid NOT NULL,
    workout_id uuid NOT NULL,
    action character varying(50) NOT NULL,
    composition jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    user_id uuid NOT NULL,
    CONSTRAINT ck_workout_action_action CHECK (((action)::text = ANY ((ARRAY['edit'::character varying, 'delete'::character varying])::text[])))
);


ALTER TABLE public.workout_action OWNER TO "training-api";

--
-- Name: workout_feedback; Type: TABLE; Schema: public; Owner: training-api
--

CREATE TABLE public.workout_feedback (
    id uuid NOT NULL,
    workout_id uuid NOT NULL,
    workout_name text NOT NULL,
    scheduled_date timestamp with time zone NOT NULL,
    detected_at timestamp with time zone NOT NULL,
    acknowledged_at timestamp with time zone,
    reason text NOT NULL,
    reason_note text,
    action text NOT NULL,
    new_date timestamp with time zone,
    dismissed boolean NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    user_id uuid NOT NULL,
    CONSTRAINT ck_workout_feedback_action CHECK ((action = ANY (ARRAY['move'::text, 'adjust'::text, 'skip'::text]))),
    CONSTRAINT ck_workout_feedback_reason CHECK ((reason = ANY (ARRAY['busy'::text, 'tired'::text, 'weather'::text, 'soreness'::text, 'motivation'::text, 'other'::text])))
);


ALTER TABLE public.workout_feedback OWNER TO "training-api";

--
-- Name: workout_inventory; Type: TABLE; Schema: public; Owner: training-api
--

CREATE TABLE public.workout_inventory (
    id uuid NOT NULL,
    display_name text NOT NULL,
    year integer,
    month integer,
    day integer,
    hour integer,
    minute integer,
    complete boolean NOT NULL,
    synced_at timestamp with time zone DEFAULT now() NOT NULL,
    user_id uuid NOT NULL
);


ALTER TABLE public.workout_inventory OWNER TO "training-api";

--
-- Name: workout_queue; Type: TABLE; Schema: public; Owner: training-api
--

CREATE TABLE public.workout_queue (
    id uuid NOT NULL,
    activity_type character varying(100) NOT NULL,
    title character varying(255) NOT NULL,
    description text,
    workout_data jsonb,
    status character varying(50) NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    fetched_at timestamp with time zone,
    completed_at timestamp with time zone,
    plan_id uuid,
    scheduled_date timestamp with time zone,
    user_id uuid NOT NULL
);


ALTER TABLE public.workout_queue OWNER TO "training-api";

--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: training-api
--

COPY public.alembic_version (version_num) FROM stdin;
c9d0e1f2a3b4
\.


--
-- Data for Name: api_tokens; Type: TABLE DATA; Schema: public; Owner: training-api
--

COPY public.api_tokens (id, user_id, token_hash, name, created_at, last_used_at, expires_at, last_user_agent) FROM stdin;
\.


--
-- Data for Name: auth_events; Type: TABLE DATA; Schema: public; Owner: training-api
--

COPY public.auth_events (id, event, username, user_id, actor_user_id, ip, detail, created_at) FROM stdin;
\.


--
-- Data for Name: daily_health_metrics; Type: TABLE DATA; Schema: public; Owner: training-api
--

COPY public.daily_health_metrics (id, date, sleep_duration, sleep_stages, resting_heart_rate, hrv_sdnn, weight, vo2_max, steps, active_energy_burned, body_fat_percentage, lean_body_mass, respiratory_rate, spo2, created_at, updated_at, user_id, basal_energy_burned) FROM stdin;
\.


--
-- Data for Name: daily_nutrition; Type: TABLE DATA; Schema: public; Owner: training-api
--

COPY public.daily_nutrition (id, user_id, date, energy_kcal, carbs_g, protein_g, fat_g, saturated_fat_g, fiber_g, sugar_g, sodium_mg, potassium_mg, cholesterol_mg, water_ml, caffeine_mg, micros, entry_count, sources, partial, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: plan_note; Type: TABLE DATA; Schema: public; Owner: training-api
--

COPY public.plan_note (id, plan_id, kind, summary, body, importance, conversation_id, expires_at, created_at, updated_at, user_id) FROM stdin;
\.


--
-- Data for Name: plans; Type: TABLE DATA; Schema: public; Owner: training-api
--

COPY public.plans (id, name, activity_type, status, start_date, end_date, description, metadata, created_at, updated_at, user_id) FROM stdin;
\.


--
-- Data for Name: sleep_samples; Type: TABLE DATA; Schema: public; Owner: training-api
--

COPY public.sleep_samples (id, user_id, start_at, end_at, stage, source, created_at) FROM stdin;
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: training-api
--

COPY public.users (id, username, password_hash, display_name, role, is_active, created_at, data_consent, data_consent_updated_at, data_consent_reported_at, units, units_updated_at) FROM stdin;
57088fa8-3a8a-434c-9af7-264389534113	admin	\N	Admin	admin	t	2026-11-12 17:12:10.973994+00	{training,recovery,body,activity,nutrition}	\N	\N	\N	\N
\.


--
-- Data for Name: workout; Type: TABLE DATA; Schema: public; Owner: training-api
--

COPY public.workout (id, activity_type, start_date, end_date, duration, total_distance, total_energy_burned, source, data, created_at, updated_at, plan_workout_id, effort_score, estimated_effort_score, user_id) FROM stdin;
\.


--
-- Data for Name: workout_action; Type: TABLE DATA; Schema: public; Owner: training-api
--

COPY public.workout_action (id, workout_id, action, composition, created_at, user_id) FROM stdin;
\.


--
-- Data for Name: workout_feedback; Type: TABLE DATA; Schema: public; Owner: training-api
--

COPY public.workout_feedback (id, workout_id, workout_name, scheduled_date, detected_at, acknowledged_at, reason, reason_note, action, new_date, dismissed, created_at, user_id) FROM stdin;
\.


--
-- Data for Name: workout_inventory; Type: TABLE DATA; Schema: public; Owner: training-api
--

COPY public.workout_inventory (id, display_name, year, month, day, hour, minute, complete, synced_at, user_id) FROM stdin;
\.


--
-- Data for Name: workout_queue; Type: TABLE DATA; Schema: public; Owner: training-api
--

COPY public.workout_queue (id, activity_type, title, description, workout_data, status, created_at, fetched_at, completed_at, plan_id, scheduled_date, user_id) FROM stdin;
\.


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: training-api
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: api_tokens api_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: training-api
--

ALTER TABLE ONLY public.api_tokens
    ADD CONSTRAINT api_tokens_pkey PRIMARY KEY (id);


--
-- Name: auth_events auth_events_pkey; Type: CONSTRAINT; Schema: public; Owner: training-api
--

ALTER TABLE ONLY public.auth_events
    ADD CONSTRAINT auth_events_pkey PRIMARY KEY (id);


--
-- Name: daily_health_metrics daily_health_metrics_pkey; Type: CONSTRAINT; Schema: public; Owner: training-api
--

ALTER TABLE ONLY public.daily_health_metrics
    ADD CONSTRAINT daily_health_metrics_pkey PRIMARY KEY (id);


--
-- Name: daily_nutrition daily_nutrition_pkey; Type: CONSTRAINT; Schema: public; Owner: training-api
--

ALTER TABLE ONLY public.daily_nutrition
    ADD CONSTRAINT daily_nutrition_pkey PRIMARY KEY (id);


--
-- Name: plan_note plan_note_pkey; Type: CONSTRAINT; Schema: public; Owner: training-api
--

ALTER TABLE ONLY public.plan_note
    ADD CONSTRAINT plan_note_pkey PRIMARY KEY (id);


--
-- Name: plans plans_pkey; Type: CONSTRAINT; Schema: public; Owner: training-api
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT plans_pkey PRIMARY KEY (id);


--
-- Name: sleep_samples sleep_samples_pkey; Type: CONSTRAINT; Schema: public; Owner: training-api
--

ALTER TABLE ONLY public.sleep_samples
    ADD CONSTRAINT sleep_samples_pkey PRIMARY KEY (id);


--
-- Name: api_tokens uq_api_tokens_token_hash; Type: CONSTRAINT; Schema: public; Owner: training-api
--

ALTER TABLE ONLY public.api_tokens
    ADD CONSTRAINT uq_api_tokens_token_hash UNIQUE (token_hash);


--
-- Name: daily_health_metrics uq_daily_health_metrics_user_date; Type: CONSTRAINT; Schema: public; Owner: training-api
--

ALTER TABLE ONLY public.daily_health_metrics
    ADD CONSTRAINT uq_daily_health_metrics_user_date UNIQUE (user_id, date);


--
-- Name: daily_nutrition uq_daily_nutrition_user_date; Type: CONSTRAINT; Schema: public; Owner: training-api
--

ALTER TABLE ONLY public.daily_nutrition
    ADD CONSTRAINT uq_daily_nutrition_user_date UNIQUE (user_id, date);


--
-- Name: sleep_samples uq_sleep_samples_identity; Type: CONSTRAINT; Schema: public; Owner: training-api
--

ALTER TABLE ONLY public.sleep_samples
    ADD CONSTRAINT uq_sleep_samples_identity UNIQUE (user_id, start_at, end_at, stage, source);


--
-- Name: users uq_users_username; Type: CONSTRAINT; Schema: public; Owner: training-api
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT uq_users_username UNIQUE (username);


--
-- Name: workout_feedback uq_workout_feedback_user_workout; Type: CONSTRAINT; Schema: public; Owner: training-api
--

ALTER TABLE ONLY public.workout_feedback
    ADD CONSTRAINT uq_workout_feedback_user_workout UNIQUE (user_id, workout_id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: training-api
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: workout_action workout_action_pkey; Type: CONSTRAINT; Schema: public; Owner: training-api
--

ALTER TABLE ONLY public.workout_action
    ADD CONSTRAINT workout_action_pkey PRIMARY KEY (id);


--
-- Name: workout_feedback workout_feedback_pkey; Type: CONSTRAINT; Schema: public; Owner: training-api
--

ALTER TABLE ONLY public.workout_feedback
    ADD CONSTRAINT workout_feedback_pkey PRIMARY KEY (id);


--
-- Name: workout_inventory workout_inventory_pkey; Type: CONSTRAINT; Schema: public; Owner: training-api
--

ALTER TABLE ONLY public.workout_inventory
    ADD CONSTRAINT workout_inventory_pkey PRIMARY KEY (id);


--
-- Name: workout workout_pkey; Type: CONSTRAINT; Schema: public; Owner: training-api
--

ALTER TABLE ONLY public.workout
    ADD CONSTRAINT workout_pkey PRIMARY KEY (id);


--
-- Name: workout_queue workout_queue_pkey; Type: CONSTRAINT; Schema: public; Owner: training-api
--

ALTER TABLE ONLY public.workout_queue
    ADD CONSTRAINT workout_queue_pkey PRIMARY KEY (id);


--
-- Name: idx_workout_feedback_action; Type: INDEX; Schema: public; Owner: training-api
--

CREATE INDEX idx_workout_feedback_action ON public.workout_feedback USING btree (action);


--
-- Name: idx_workout_feedback_scheduled; Type: INDEX; Schema: public; Owner: training-api
--

CREATE INDEX idx_workout_feedback_scheduled ON public.workout_feedback USING btree (scheduled_date DESC);


--
-- Name: idx_workout_feedback_workout; Type: INDEX; Schema: public; Owner: training-api
--

CREATE INDEX idx_workout_feedback_workout ON public.workout_feedback USING btree (workout_id);


--
-- Name: ix_api_tokens_token_hash; Type: INDEX; Schema: public; Owner: training-api
--

CREATE INDEX ix_api_tokens_token_hash ON public.api_tokens USING btree (token_hash);


--
-- Name: ix_api_tokens_user_id; Type: INDEX; Schema: public; Owner: training-api
--

CREATE INDEX ix_api_tokens_user_id ON public.api_tokens USING btree (user_id);


--
-- Name: ix_auth_events_created_at; Type: INDEX; Schema: public; Owner: training-api
--

CREATE INDEX ix_auth_events_created_at ON public.auth_events USING btree (created_at);


--
-- Name: ix_auth_events_event; Type: INDEX; Schema: public; Owner: training-api
--

CREATE INDEX ix_auth_events_event ON public.auth_events USING btree (event);


--
-- Name: ix_auth_events_user_id; Type: INDEX; Schema: public; Owner: training-api
--

CREATE INDEX ix_auth_events_user_id ON public.auth_events USING btree (user_id);


--
-- Name: ix_daily_health_metrics_user_id; Type: INDEX; Schema: public; Owner: training-api
--

CREATE INDEX ix_daily_health_metrics_user_id ON public.daily_health_metrics USING btree (user_id);


--
-- Name: ix_daily_nutrition_user_date; Type: INDEX; Schema: public; Owner: training-api
--

CREATE INDEX ix_daily_nutrition_user_date ON public.daily_nutrition USING btree (user_id, date);


--
-- Name: ix_daily_nutrition_user_id; Type: INDEX; Schema: public; Owner: training-api
--

CREATE INDEX ix_daily_nutrition_user_id ON public.daily_nutrition USING btree (user_id);


--
-- Name: ix_plan_note_conversation_id; Type: INDEX; Schema: public; Owner: training-api
--

CREATE INDEX ix_plan_note_conversation_id ON public.plan_note USING btree (conversation_id);


--
-- Name: ix_plan_note_created_at; Type: INDEX; Schema: public; Owner: training-api
--

CREATE INDEX ix_plan_note_created_at ON public.plan_note USING btree (created_at);


--
-- Name: ix_plan_note_kind; Type: INDEX; Schema: public; Owner: training-api
--

CREATE INDEX ix_plan_note_kind ON public.plan_note USING btree (kind);


--
-- Name: ix_plan_note_plan_id; Type: INDEX; Schema: public; Owner: training-api
--

CREATE INDEX ix_plan_note_plan_id ON public.plan_note USING btree (plan_id);


--
-- Name: ix_plan_note_user_id; Type: INDEX; Schema: public; Owner: training-api
--

CREATE INDEX ix_plan_note_user_id ON public.plan_note USING btree (user_id);


--
-- Name: ix_plans_activity_type; Type: INDEX; Schema: public; Owner: training-api
--

CREATE INDEX ix_plans_activity_type ON public.plans USING btree (activity_type);


--
-- Name: ix_plans_status; Type: INDEX; Schema: public; Owner: training-api
--

CREATE INDEX ix_plans_status ON public.plans USING btree (status);


--
-- Name: ix_plans_user_id; Type: INDEX; Schema: public; Owner: training-api
--

CREATE INDEX ix_plans_user_id ON public.plans USING btree (user_id);


--
-- Name: ix_sleep_samples_user_id; Type: INDEX; Schema: public; Owner: training-api
--

CREATE INDEX ix_sleep_samples_user_id ON public.sleep_samples USING btree (user_id);


--
-- Name: ix_sleep_samples_user_span; Type: INDEX; Schema: public; Owner: training-api
--

CREATE INDEX ix_sleep_samples_user_span ON public.sleep_samples USING btree (user_id, end_at, start_at);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: training-api
--

CREATE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: ix_workout_action_created_at; Type: INDEX; Schema: public; Owner: training-api
--

CREATE INDEX ix_workout_action_created_at ON public.workout_action USING btree (created_at);


--
-- Name: ix_workout_action_user_id; Type: INDEX; Schema: public; Owner: training-api
--

CREATE INDEX ix_workout_action_user_id ON public.workout_action USING btree (user_id);


--
-- Name: ix_workout_activity_start; Type: INDEX; Schema: public; Owner: training-api
--

CREATE INDEX ix_workout_activity_start ON public.workout USING btree (activity_type, start_date);


--
-- Name: ix_workout_activity_type; Type: INDEX; Schema: public; Owner: training-api
--

CREATE INDEX ix_workout_activity_type ON public.workout USING btree (activity_type);


--
-- Name: ix_workout_feedback_user_id; Type: INDEX; Schema: public; Owner: training-api
--

CREATE INDEX ix_workout_feedback_user_id ON public.workout_feedback USING btree (user_id);


--
-- Name: ix_workout_inventory_user_id; Type: INDEX; Schema: public; Owner: training-api
--

CREATE INDEX ix_workout_inventory_user_id ON public.workout_inventory USING btree (user_id);


--
-- Name: ix_workout_plan_workout_id; Type: INDEX; Schema: public; Owner: training-api
--

CREATE INDEX ix_workout_plan_workout_id ON public.workout USING btree (plan_workout_id);


--
-- Name: ix_workout_queue_activity_type; Type: INDEX; Schema: public; Owner: training-api
--

CREATE INDEX ix_workout_queue_activity_type ON public.workout_queue USING btree (activity_type);


--
-- Name: ix_workout_queue_plan_id; Type: INDEX; Schema: public; Owner: training-api
--

CREATE INDEX ix_workout_queue_plan_id ON public.workout_queue USING btree (plan_id);


--
-- Name: ix_workout_queue_scheduled_date; Type: INDEX; Schema: public; Owner: training-api
--

CREATE INDEX ix_workout_queue_scheduled_date ON public.workout_queue USING btree (scheduled_date);


--
-- Name: ix_workout_queue_status; Type: INDEX; Schema: public; Owner: training-api
--

CREATE INDEX ix_workout_queue_status ON public.workout_queue USING btree (status);


--
-- Name: ix_workout_queue_user_id; Type: INDEX; Schema: public; Owner: training-api
--

CREATE INDEX ix_workout_queue_user_id ON public.workout_queue USING btree (user_id);


--
-- Name: ix_workout_start_date; Type: INDEX; Schema: public; Owner: training-api
--

CREATE INDEX ix_workout_start_date ON public.workout USING btree (start_date);


--
-- Name: ix_workout_user_id; Type: INDEX; Schema: public; Owner: training-api
--

CREATE INDEX ix_workout_user_id ON public.workout USING btree (user_id);


--
-- Name: api_tokens api_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: training-api
--

ALTER TABLE ONLY public.api_tokens
    ADD CONSTRAINT api_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: auth_events auth_events_actor_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: training-api
--

ALTER TABLE ONLY public.auth_events
    ADD CONSTRAINT auth_events_actor_user_id_fkey FOREIGN KEY (actor_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: auth_events auth_events_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: training-api
--

ALTER TABLE ONLY public.auth_events
    ADD CONSTRAINT auth_events_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: daily_nutrition daily_nutrition_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: training-api
--

ALTER TABLE ONLY public.daily_nutrition
    ADD CONSTRAINT daily_nutrition_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: daily_health_metrics fk_daily_health_metrics_user_id; Type: FK CONSTRAINT; Schema: public; Owner: training-api
--

ALTER TABLE ONLY public.daily_health_metrics
    ADD CONSTRAINT fk_daily_health_metrics_user_id FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: plan_note fk_plan_note_user_id; Type: FK CONSTRAINT; Schema: public; Owner: training-api
--

ALTER TABLE ONLY public.plan_note
    ADD CONSTRAINT fk_plan_note_user_id FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: plans fk_plans_user_id; Type: FK CONSTRAINT; Schema: public; Owner: training-api
--

ALTER TABLE ONLY public.plans
    ADD CONSTRAINT fk_plans_user_id FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: workout_action fk_workout_action_user_id; Type: FK CONSTRAINT; Schema: public; Owner: training-api
--

ALTER TABLE ONLY public.workout_action
    ADD CONSTRAINT fk_workout_action_user_id FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: workout_feedback fk_workout_feedback_user_id; Type: FK CONSTRAINT; Schema: public; Owner: training-api
--

ALTER TABLE ONLY public.workout_feedback
    ADD CONSTRAINT fk_workout_feedback_user_id FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: workout_inventory fk_workout_inventory_user_id; Type: FK CONSTRAINT; Schema: public; Owner: training-api
--

ALTER TABLE ONLY public.workout_inventory
    ADD CONSTRAINT fk_workout_inventory_user_id FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: workout_queue fk_workout_queue_user_id; Type: FK CONSTRAINT; Schema: public; Owner: training-api
--

ALTER TABLE ONLY public.workout_queue
    ADD CONSTRAINT fk_workout_queue_user_id FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: workout fk_workout_user_id; Type: FK CONSTRAINT; Schema: public; Owner: training-api
--

ALTER TABLE ONLY public.workout
    ADD CONSTRAINT fk_workout_user_id FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: plan_note plan_note_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: training-api
--

ALTER TABLE ONLY public.plan_note
    ADD CONSTRAINT plan_note_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(id) ON DELETE CASCADE;


--
-- Name: sleep_samples sleep_samples_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: training-api
--

ALTER TABLE ONLY public.sleep_samples
    ADD CONSTRAINT sleep_samples_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: workout_queue workout_queue_plan_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: training-api
--

ALTER TABLE ONLY public.workout_queue
    ADD CONSTRAINT workout_queue_plan_id_fkey FOREIGN KEY (plan_id) REFERENCES public.plans(id) ON DELETE SET NULL;


--
-- PostgreSQL database dump complete
--

\unrestrict HJYeNNWX5itBwdvOJGKIip9J4YnOazu2YfjrN0k9pbYZZpWwDRA5QTBetaAr2SA

